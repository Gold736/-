package com.example.aihelper

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class OverlayService : Service() {

    // ---- Внешний вид ----
    // true = объёмный шарик (катится, есть блик и тень)
    // false = ваша картинка из res/drawable/character.png
    private val ballMode = true

    // ---- Настройки физики (можно подкручивать) ----
    private val gravityDp = 2000f      // сила тяжести, dp/с²
    private var bounceFactor = 0.5f    // упругость пола (0 = не отскакивает, 1 = идеальный отскок)
    private val wallBounce = 0.6f      // упругость стен
    private val floorFriction = 5f     // трение о пол (больше = быстрее останавливается)
    private val floorMarginDp = 56     // отступ от низа экрана (над панелью навигации)
    private var sizeDp = 90            // размер персонажа

    companion object {
        /** true, пока помощник на экране: нужно, чтобы перезапустить его после смены настроек */
        @Volatile
        var active = false
        const val ACTION_START_SHARE = "com.example.aihelper.START_SHARE"
    }

    private lateinit var cfg: Settings
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())

    private var avatar: FrameLayout? = null
    private var avatarImg: View? = null      // то, что сплющивается и вытягивается
    private var body: ImageView? = null      // тело шарика
    private var face: ImageView? = null      // лицо: улыбка или удивление
    private var glint: ImageView? = null     // блики в глазах (только при удивлении)
    private var wow = false
    private var avatarLp: WindowManager.LayoutParams? = null
    private var shadowView: View? = null
    private var shadowLp: WindowManager.LayoutParams? = null
    private var chat: LinearLayout? = null
    private var log: TextView? = null
    private var scroll: ScrollView? = null

    private var idle: Animator? = null

    // Состояние физики (пиксели и пиксели в секунду)
    private var px = 0f
    private var py = 0f
    private var vx = 0f
    private var vy = 0f
    private var squash = 0f
    private var dragging = false
    private var running = false
    private var lastNanos = 0L
    private var tracker: VelocityTracker? = null

    // Голос
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var input: EditText? = null
    private var micBtn: Button? = null
    private var eyeBtn: Button? = null
    private lateinit var share: ScreenShare

    private val lines = mutableListOf<String>()
    private val history = mutableListOf<Pair<String, String>>()

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val dt = if (lastNanos == 0L) 0.016f
            else ((frameTimeNanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.032f)
            lastNanos = frameTimeNanos
            step(dt)
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // Раз в несколько секунд персонаж сам подпрыгивает в сторону
    private val wanderTask = object : Runnable {
        override fun run() {
            if (cfg.hopFreq == 0) return
            if (!dragging && !running && chat == null) hop()
            val delay = if (cfg.hopFreq == 2) (1500L..3500L).random() else (3500L..7000L).random()
            ui.postDelayed(this, delay)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_SHARE) {
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data")
            val code = intent.getIntExtra("resultCode", 0)
            // Android 14+: тип mediaProjection объявляем только после согласия пользователя
            startAsForeground(sharing = true)
            if (data != null) {
                runCatching {
                    share.start(code, data, cfg.shotMaxSide) {
                        startAsForeground(sharing = false)
                        updateEye()
                    }
                }.onFailure {
                    startAsForeground(sharing = false)
                    addNote("${cfg.name}: не удалось включить показ экрана: ${it.message}")
                }
            }
            updateEye()
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        cfg = Settings(this)
        sizeDp = cfg.sizeDp
        bounceFactor = cfg.bounce / 100f
        active = true
        share = ScreenShare(this, ui)
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        wm =getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showAvatar()
        wake() // персонаж падает на пол с отскоками
        if (cfg.hopFreq > 0) ui.postDelayed(wanderTask, 3000)
    }

    override fun onDestroy() {
        active = false
        ui.removeCallbacks(wanderTask)
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        idle?.cancel()
        tracker?.recycle()
        tracker = null
        stopListening()
        share.stop()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        chat?.let { runCatching { wm.removeView(it) } }
        avatar?.let { runCatching { wm.removeView(it) } }
        shadowView?.let { runCatching { wm.removeView(it) } }
        chat = null
        avatar = null
        shadowView = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground(sharing: Boolean = false) {
        val channelId = "helper"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Крон", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle(if (sharing) "Крон видит экран" else "Крон работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (sharing) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(1, notification, type)
        } else if (Build.VERSION.SDK_INT >= 29 && sharing) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    // ---------- Физика ----------

    private fun wake() {
        if (running) return
        running = true
        lastNanos = 0L
        idle?.cancel()
        idle = null
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun resetImg() {
        avatarImg?.apply {
            translationY = 0f
            scaleX = 1f
            scaleY = 1f
            rotation = 0f
        }
    }

    /** Лёгкое «дыхание», пока персонаж стоит на полу. */
    private fun startIdle() {
        val img = avatarImg ?: return
        idle?.cancel()
        val a = ObjectAnimator.ofPropertyValuesHolder(
            img,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1.03f, 0.97f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.96f, 1.04f)
        )
        a.duration = 700
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.interpolator = AccelerateDecelerateInterpolator()
        a.start()
        idle = a
    }

    private fun floorY(): Float =
        (resources.displayMetrics.heightPixels - dp(sizeDp) - dp(floorMarginDp)).toFloat()

    /** Тень лежит на полу и становится меньше и бледнее, когда шарик высоко. */
    private fun updateShadow() {
        val sh = shadowView ?: return
        val lp = shadowLp ?: return
        val floor = floorY()
        val h = ((floor - py) / max(floor, 1f)).coerceIn(0f, 1f)
        lp.x = px.toInt()
        lp.y = (floor + dp(sizeDp) - dp(9)).toInt()
        sh.scaleX = 1f - 0.5f * h
        sh.alpha = 0.9f * (1f - 0.7f * h)
        if (sh.isAttachedToWindow) runCatching { wm.updateViewLayout(sh, lp) }
    }

    /** Один кадр физики: гравитация, отскоки от пола и стен, трение. */
    private fun step(dt: Float) {
        val lp = avatarLp ?: return
        val view = avatar ?: return
        val img = avatarImg ?: return

        val size = dp(sizeDp).toFloat()
        val maxX = resources.displayMetrics.widthPixels - size
        val floor = floorY()

        vy += resources.displayMetrics.density * gravityDp * dt
        px += vx * dt
        py += vy * dt

        if (px < 0f) {
            px = 0f
            vx = -vx * wallBounce
        } else if (px > maxX) {
            px = maxX
            vx = -vx * wallBounce
        }
        if (py < 0f) {
            py = 0f
            vy = abs(vy) * 0.5f
        }

        var impact = 0f
        if (py >= floor) {
            py = floor
            if (vy > dp(250)) {
                impact = vy
                vy = -vy * bounceFactor
            } else {
                vy = 0f
            }
            vx *= max(0f, 1f - floorFriction * dt)
        }
        val grounded = py >= floor - 1f && abs(vy) < 1f

        // В полёте на большой скорости смайл удивляется, на полу улыбается
        setFace(!grounded && abs(vy) + abs(vx) > dp(900))

        // Сплющивание при ударе о пол, затем плавное восстановление формы
        squash = if (impact > 0f) (impact / dp(2500)).coerceIn(0.05f, 0.35f)
        else squash * max(0f, 1f - 12f * dt)

        // Вытягивание в полёте по скорости
        val stretch = if (grounded) 0f else min(abs(vy) / dp(3000), 0.25f)
        img.scaleY = 1f + stretch - squash
        img.scaleX = 1f - stretch * 0.6f + squash * 0.7f

        if (ballMode) {
            // Шарик катится: угол поворота = пройденный путь / радиус
            body?.let { it.rotation += (vx * dt / (size / 2f)) * 57.2958f }
        } else {
            val targetRot = if (grounded) 0f else (vx / dp(60)).coerceIn(-25f, 25f)
            img.rotation += (targetRot - img.rotation) * min(1f, 12f * dt)
        }

        lp.x = px.toInt()
        lp.y = py.toInt()
        if (view.isAttachedToWindow) runCatching { wm.updateViewLayout(view, lp) }
        updateShadow()

        // Остановились: выключаем физику, чтобы не тратить батарею
        if (grounded && abs(vx) < dp(8) && squash < 0.01f) {
            vx = 0f
            vy = 0f
            running = false
            setFace(false)
            resetImg()
            startIdle()
        }
    }

    private fun setFace(wowNow: Boolean) {
        if (wowNow == wow) return
        wow = wowNow
        face?.setImageResource(if (wowNow) R.drawable.face_wow else R.drawable.face_smile)
        glint?.visibility = if (wowNow) View.VISIBLE else View.INVISIBLE
    }

    /** Толчок: прыжок вверх и немного вбок. */
    private fun hop() {
        val dir = if (Random.nextBoolean()) 1 else -1
        vy = -dp(Random.nextInt(700, 1100)).toFloat()
        vx = dir * dp(Random.nextInt(250, 600)).toFloat()
        wake()
    }

    private fun bounceUp(strengthDp: Int) {
        if (dragging) return
        vy = -dp(strengthDp).toFloat()
        wake()
    }

    // ---------- Персонаж на экране ----------

    private fun showAvatar() {
        val size = dp(sizeDp)

        // Тень на полу: отдельное окно под персонажем (его не видно пальцем)
        val sh = View(this)
        sh.setBackgroundResource(R.drawable.ball_shadow)
        val shLp = WindowManager.LayoutParams(
            size, dp(18),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(sh, shLp)
        shadowView = sh
        shadowLp = shLp

        // Сам персонаж
        val holder = FrameLayout(this)
        holder.pivotX = size / 2f
        holder.pivotY = size.toFloat()
        if (ballMode) {
            val b = ImageView(this)
            b.setImageResource(R.drawable.ball_body)
            b.setColorFilter(cfg.ballColor, PorterDuff.Mode.SRC_IN)
            val blush = ImageView(this)
            blush.setImageResource(R.drawable.face_blush)
            val f = ImageView(this)
            f.setImageResource(R.drawable.face_smile)
            f.setColorFilter(cfg.faceColor, PorterDuff.Mode.SRC_IN)
            val g = ImageView(this)
            g.setImageResource(R.drawable.face_glint)
            g.visibility = View.INVISIBLE
            val shade = ImageView(this)
            shade.setImageResource(R.drawable.ball_shade)
            holder.addView(b, FrameLayout.LayoutParams(size, size))
            holder.addView(blush, FrameLayout.LayoutParams(size, size))
            holder.addView(f, FrameLayout.LayoutParams(size, size))
            holder.addView(g, FrameLayout.LayoutParams(size, size))
            holder.addView(shade, FrameLayout.LayoutParams(size, size))
            body = b
            face = f
            glint = g
        } else {
            val pic = ImageView(this)
            pic.setImageResource(R.drawable.character)
            holder.addView(pic, FrameLayout.LayoutParams(size, size))
        }
        val box = FrameLayout(this)
        box.addView(holder, FrameLayout.LayoutParams(size, size))

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(20)
            y = dp(250)
        }
        px = lp.x.toFloat()
        py = lp.y.toFloat()

        box.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0f
            var startY = 0f
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                tracker?.addMovement(e)
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        running = false
                        dragging = true
                        idle?.cancel()
                        idle = null
                        resetImg()
                        holder.scaleX = 1.1f
                        holder.scaleY = 0.9f
                        setFace(true)
                        vx = 0f
                        vy = 0f
                        tracker?.recycle()
                        tracker = VelocityTracker.obtain().also { it.addMovement(e) }
                        startX = px; startY = py
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                            if (!moved) {
                                holder.scaleX = 1f
                                holder.scaleY = 1f
                            }
                            moved = true
                        }
                        if (moved) {
                            px = startX + dx
                            py = startY + dy
                            lp.x = px.toInt()
                            lp.y = py.toInt()
                            if (!ballMode) holder.rotation = (dx / 8f).coerceIn(-20f, 20f)
                            wm.updateViewLayout(box, lp)
                            updateShadow()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        dragging = false
                        resetImg()
                        if (moved) {
                            // бросок: персонаж улетает с той скоростью, с которой его отпустили
                            val t = tracker
                            if (t != null) {
                                t.computeCurrentVelocity(1000)
                                val maxV = dp(3500).toFloat()
                                vx = t.xVelocity.coerceIn(-maxV, maxV)
                                vy = t.yVelocity.coerceIn(-maxV, maxV)
                            }
                        } else if (e.action == MotionEvent.ACTION_UP) {
                            toggleChat()
                            vy = -dp(800).toFloat()
                        }
                        tracker?.recycle()
                        tracker = null
                        wake()
                    }
                }
                return true
            }
        })

        wm.addView(box, lp)
        avatar = box
        avatarImg = holder
        avatarLp = lp
        updateShadow()
    }

    // ---------- Чат ----------

    private fun toggleChat() {
        val existing = chat
        if (existing != null) {
            stopListening()
            tts?.stop()
            runCatching { wm.removeView(existing) }
            chat = null
            input = null
            micBtn = null
            eyeBtn = null
        } else {
            showChat()
        }
    }

    private fun showChat() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.LTGRAY)
            }
        }

        val logView = TextView(this).apply {
            setTextColor(Color.BLACK)
            textSize = 14f
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val scrollView = ScrollView(this).apply { addView(logView) }
        box.addView(scrollView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))

        val input = EditText(this).apply {
            hint = "Напишите вопрос…"
            setTextColor(Color.BLACK)
            setHintTextColor(Color.GRAY)
            maxLines = 3
        }
        val mic = Button(this).apply { text = "🎤"; minWidth = 0; minimumWidth = 0 }
        val eye = Button(this).apply { text = "👁"; minWidth = 0; minimumWidth = 0 }
        val sendBtn = Button(this).apply { text = "Отправить" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(eye)
        row.addView(mic)
        row.addView(sendBtn)
        box.addView(row)
        this.input = input
        micBtn = mic
        eyeBtn = eye
        updateEye()

        sendBtn.setOnClickListener {
            tts?.stop()
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                send(text)
            }
        }
        eye.setOnClickListener {
            if (share.isOn) {
                share.stop()
                startAsForeground(sharing = false)
                updateEye()
                addNote("${cfg.name}: больше не вижу ваш экран.")
            } else {
                startActivity(
                    Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        mic.setOnClickListener {
            if (listening) stopListening() else startListening()
        }

        val lp = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        wm.addView(box, lp)
        chat = box
        log = logView
        scroll = scrollView
        render(false)
    }

    private fun render(pending: Boolean) {
        val text = lines.joinToString("\n\n") + if (pending) "\n\n…" else ""
        log?.text = text
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- Показ экрана ----------

    private fun updateEye() {
        eyeBtn?.text = if (share.isOn) "👁✔" else "👁"
    }

    /** Прячем чат и шарик, чтобы они не попали на снимок, и берём кадр экрана. */
    private fun captureScreen(done: (String?) -> Unit) {
        val hidden = if (cfg.hideOnShot) listOfNotNull(chat, avatar, shadowView) else emptyList()
        hidden.forEach { it.visibility = View.INVISIBLE }
        ui.postDelayed({
            val img = share.grabJpegBase64()
            hidden.forEach { it.visibility = View.VISIBLE }
            done(img)
        }, 350)
    }

    // ---------- Голос ----------

    private fun addNote(text: String) {
        lines.add(text)
        render(false)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addNote("${cfg.name}: нет доступа к микрофону. Откройте приложение и нажмите «Разрешить микрофон».")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addNote("${cfg.name}: на телефоне нет службы распознавания речи (обычно это приложение «Google»).")
            return
        }
        tts?.stop() // не слушаем собственный голос

        val rec = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) input?.setText(t)
                }

                override fun onResults(results: Bundle?) {
                    setListening(false)
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    input?.setText("")
                    if (!t.isNullOrBlank()) send(t.trim(), byVoice = true)
                }

                override fun onError(error: Int) {
                    setListening(false)
                    input?.setText("")
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не расслышал, попробуйте ещё раз."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Нет сети для распознавания речи."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону."
                        else -> "Не удалось распознать речь (код $error)."
                    }
                    addNote("${cfg.name}: $msg")
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer = r
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            val tag = cfg.voiceLangTag
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (tag.isEmpty()) Locale.getDefault().toLanguageTag() else tag)
        }
        setListening(true)
        rec.startListening(intent)
    }

    private fun stopListening() {
        if (!listening) return
        setListening(false)
        recognizer?.cancel()
        input?.setText("")
    }

    private fun setListening(on: Boolean) {
        listening = on
        micBtn?.text = if (on) "⏹" else "🎤"
        input?.hint = if (on) "Слушаю…" else "Напишите вопрос…"
    }

    /** Озвучка: убираем разметку, язык выбираем по настройке или по буквам в тексте. */
    private fun speak(text: String) {
        val engine = tts ?: return
        if (!ttsReady) return
        val clean = text.replace(Regex("[*_#`>~]"), "").replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return
        val tag = cfg.voiceLangTag
        val locale = when {
            tag.isNotEmpty() -> Locale.forLanguageTag(tag)
            clean.any { it in 'а'..'я' || it in 'А'..'Я' } -> Locale("ru", "RU")
            else -> Locale.getDefault()
        }
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "answer")
    }

    private fun send(text: String, byVoice: Boolean = false) {
        lines.add("Вы: $text")
        val key = cfg.apiKey
        if (key.isEmpty()) {
            lines.add("${cfg.name}: сначала введите API-ключ в приложении.")
            render(false)
            return
        }
        history.add("user" to text)
        render(true)

        if (share.isOn) {
            captureScreen { img ->
                if (img == null) lines.add("(не удалось снять экран, отвечаю без него)")
                else lines[lines.lastIndex] = lines.last() + " 👁"
                ask(key, byVoice, img)
            }
        } else {
            ask(key, byVoice, null)
        }
    }

    private fun ask(key: String, byVoice: Boolean, image: String?) {
        Thread {
            val result = ClaudeClient.ask(
                key, history.toList(), cfg.modelId, cfg.systemPrompt(), cfg.maxTokens, image
            )
            ui.post {
                result.onSuccess { answer ->
                    history.add("assistant" to answer)
                    lines.add("${cfg.name}: $answer")
                    bounceUp(700)
                    if (byVoice || cfg.voiceReply) speak(answer)
                }.onFailure { error ->
                    // убираем неотвеченный вопрос, чтобы история осталась корректной
                    history.removeAt(history.lastIndex)
                    lines.add("Ошибка: ${error.message}")
                }
                render(false)
            }
        }.start()
    }
}
