package com.example.aihelper

import android.content.Context

/** Все настройки помощника хранятся на телефоне в SharedPreferences. */
class Settings(context: Context) {
    private val p = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v).apply() }

    var name: String
        get() = (p.getString("name", "Крон") ?: "Крон").ifBlank { "Крон" }
        set(v) { p.edit().putString("name", v).apply() }

    var persona: Int
        get() = p.getInt("persona", 0)
        set(v) { p.edit().putInt("persona", v).apply() }

    var customPrompt: String
        get() = p.getString("custom", "") ?: ""
        set(v) { p.edit().putString("custom", v).apply() }

    var length: Int
        get() = p.getInt("length", 1)
        set(v) { p.edit().putInt("length", v).apply() }

    var model: Int
        get() = p.getInt("model", 0)
        set(v) { p.edit().putInt("model", v).apply() }

    var sizeDp: Int
        get() = p.getInt("size", 90)
        set(v) { p.edit().putInt("size", v).apply() }

    /** Упругость отскока в процентах (20–80). */
    var bounce: Int
        get() = p.getInt("bounce", 50)
        set(v) { p.edit().putInt("bounce", v).apply() }

    /** 0 = не прыгает сам, 1 = иногда, 2 = часто. */
    var hopFreq: Int
        get() = p.getInt("hop", 1)
        set(v) { p.edit().putInt("hop", v).apply() }

    /** Озвучивать все ответы. Ответ на вопрос, заданный голосом, озвучивается всегда. */
    var voiceReply: Boolean
        get() = p.getBoolean("voiceReply", false)
        set(v) { p.edit().putBoolean("voiceReply", v).apply() }

    /** Язык для распознавания речи и озвучки (тег вроде "ru-RU"); пустая строка = язык телефона. */
    var voiceLangTag: String
        get() = p.getString("voiceLangTag", "") ?: ""
        set(v) { p.edit().putString("voiceLangTag", v).apply() }

    /** Огрызаться в ответ на грубость пользователя. */
    var snark: Boolean
        get() = p.getBoolean("snark", true)
        set(v) { p.edit().putBoolean("snark", v).apply() }

    /** Цвет шарика (ARGB). Любой: готовый из BALL_COLORS или свой, подобранный ползунками. */
    var ballColor: Int
        get() = p.getInt("ballColorV", 0xFFFFD23F.toInt())
        set(v) { p.edit().putInt("ballColorV", v).apply() }

    /** Цвет лица (глаза и рот). */
    var faceColor: Int
        get() = p.getInt("faceColorV", 0xFF3B2A00.toInt())
        set(v) { p.edit().putInt("faceColorV", v).apply() }

    /** Качество снимка экрана: индекс в SHOT_QUALITY. */
    var shotQuality: Int
        get() = p.getInt("shotQuality", 1)
        set(v) { p.edit().putInt("shotQuality", v).apply() }

    /** Прятать чат и шарик на снимке экрана. */
    var hideOnShot: Boolean
        get() = p.getBoolean("hideOnShot", true)
        set(v) { p.edit().putBoolean("hideOnShot", v).apply() }

    /** Длинная сторона снимка в пикселях. */
    val shotMaxSide: Int
        get() = SHOT_QUALITY[shotQuality.coerceIn(0, SHOT_QUALITY.lastIndex)].second

    val modelId: String
        get() = MODELS[model.coerceIn(0, MODELS.lastIndex)].second

    val maxTokens: Int
        get() = when (length) {
            0 -> 400
            2 -> 2048
            else -> 1024
        }

    /** Инструкция для Claude: имя, характер, длина ответа и ваши дополнения. */
    fun systemPrompt(): String {
        val custom = customPrompt.trim()
        return buildString {
            append("Ты личный помощник, который живёт на экране телефона. Тебя зовут $name. ")
            append(PERSONAS[persona.coerceIn(0, PERSONAS.lastIndex)].second).append(' ')
            append(LENGTHS[length.coerceIn(0, LENGTHS.lastIndex)].second).append(' ')
            append("Отвечай на языке пользователя. ")
            append("Если к сообщению приложен скриншот, это экран телефона пользователя в момент вопроса: опирайся на него.")
            if (snark) {
                append("\nЕсли пользователь груб или агрессивен к тебе, отвечай ему в той же манере: ")
                append("дерзко, колко, с сарказмом и коротко, без заискивания и извинений. ")
                append("Но без мата, без оскорблений по национальности, полу, внешности, здоровью или другим признакам и без угроз. ")
                append("Если резкость пользователя похожа на признак того, что ему плохо, или речь о безопасности, ")
                append("сразу переходи на спокойный и тёплый тон. Когда пользователь снова вежлив, возвращайся к обычному характеру.")
            }
            if (custom.isNotEmpty()) {
                append("\nДополнительные инструкции владельца:\n").append(custom)
            }
        }
    }

    companion object {
        val PERSONAS = listOf(
            "Дружелюбный" to "Ты дружелюбный и тёплый помощник.",
            "Строго и по делу" to "Отвечай сухо и по делу, без лишних слов и эмоций.",
            "Весёлый" to "Ты весёлый помощник: шути к месту и иногда добавляй эмодзи.",
            "Учитель" to "Объясняй простыми словами, как терпеливый учитель, с короткими примерами."
        )
        val LENGTHS = listOf(
            "Коротко" to "Отвечай в 1–2 предложениях.",
            "Средне" to "Отвечай в 2–5 предложениях.",
            "Подробно" to "Отвечай подробно, но структурированно."
        )
        val MODELS = listOf(
            "Sonnet 5.5: баланс скорости и ума" to "claude-sonnet-5-5",
            "Haiku 5.5: быстрее и дешевле" to "claude-haiku-5-5",
            "Opus 5.5: умнее, но дороже" to "claude-opus-5-5"
        )
        /**
         * Все языки, которые знает телефон: пары (название, тег). Первым идёт «как в телефоне»,
         * затем самые частые, затем остальные по алфавиту.
         */
        fun allVoiceLangs(): List<Pair<String, String>> {
            val ru = java.util.Locale("ru")
            fun name(l: java.util.Locale): String {
                val n = l.getDisplayName(ru).replaceFirstChar { it.uppercase() }
                return "$n  (${l.toLanguageTag()})"
            }
            val all = java.util.Locale.getAvailableLocales()
                .filter { it.language.isNotEmpty() && it.country.isNotEmpty() && it.script.isEmpty() && it.variant.isEmpty() }
                .distinctBy { it.toLanguageTag() }
                .map { name(it) to it.toLanguageTag() }
                .sortedBy { it.first }
            val top = listOf("ru-RU", "en-US", "kk-KZ", "uk-UA", "tr-TR", "de-DE", "fr-FR", "es-ES", "zh-CN")
            val head = top.map { t -> all.firstOrNull { it.second == t } ?: (t to t) }
            return listOf("Как в телефоне" to "") + head + all.filter { it.second !in top }
        }
        val BALL_COLORS = listOf(
            "Жёлтый" to 0xFFFFD23FL,
            "Оранжевый" to 0xFFFF9F43L,
            "Красный" to 0xFFFF6B6BL,
            "Розовый" to 0xFFFF8FC8L,
            "Фиолетовый" to 0xFFB388FFL,
            "Синий" to 0xFF6EA8FEL,
            "Голубой" to 0xFF5CD6E6L,
            "Зелёный" to 0xFF7BD88FL
        )
        val FACE_COLORS = listOf(
            "Коричневый" to 0xFF3B2A00L,
            "Чёрный" to 0xFF111111L,
            "Тёмно-синий" to 0xFF1B3A57L,
            "Тёмно-зелёный" to 0xFF14532DL,
            "Белый" to 0xFFFFFFFFL
        )
        val SHOT_QUALITY = listOf(
            "Низкое: быстро и дёшево" to 800,
            "Среднее" to 1280,
            "Высокое: читает мелкий текст" to 1920
        )
        val HOP_LABELS = listOf("Никогда", "Иногда", "Часто")
    }
}
