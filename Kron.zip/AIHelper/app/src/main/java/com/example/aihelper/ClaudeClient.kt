package com.example.aihelper

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {

    /** history — список пар (роль, текст): роль "user" или "assistant". */
    fun ask(
        apiKey: String,
        history: List<Pair<String, String>>,
        model: String,
        system: String,
        maxTokens: Int,
        imageBase64: String? = null   // скриншот экрана для последнего сообщения
    ): Result<String> = runCatching {
        val messages = JSONArray()
        history.forEachIndexed { i, (role, text) ->
            val content: Any = if (imageBase64 != null && i == history.lastIndex && role == "user") {
                JSONArray()
                    .put(
                        JSONObject().put("type", "image").put(
                            "source",
                            JSONObject()
                                .put("type", "base64")
                                .put("media_type", "image/jpeg")
                                .put("data", imageBase64)
                        )
                    )
                    .put(JSONObject().put("type", "text").put("text", text))
            } else text
            messages.put(JSONObject().put("role", role).put("content", content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching {
                    JSONObject(text).getJSONObject("error").getString("message")
                }.getOrDefault(text)
                throw Exception("Ошибка $code: $msg")
            }
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.getString("text"))
            }
            sb.toString().trim()
        } finally {
            conn.disconnect()
        }
    }
}
