package com.example.aihelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    // Палитра: цвета шарика
    private val yellow = 0xFFFFD23F.toInt()
    private val ink = 0xFF3B2A00.toInt()
    private val pageBg = 0xFFF7F4EA.toInt()
    private val muted = 0xFF7A7365.toInt()
    private val line = 0xFFE4DDCB.toInt()

    private lateinit var permStatus: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun margins(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Settings(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(pageBg)
            addView(root)
        })

        // ---------- Шапка: шарик + имя ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val mini = FrameLayout(this)
        val miniBody = ImageView(this).apply {
            setImageResource(R.drawable.ball_body)
            setColorFilter(cfg.ballColor, PorterDuff.Mode.SRC_IN)
        }
        mini.addView(miniBody, FrameLayout.LayoutParams(dp(56), dp(56)))
        mini.addView(ImageView(this).apply { setImageResource(R.drawable.face_blush) }, FrameLayout.LayoutParams(dp(56), dp(56)))
        val miniFace = ImageView(this).apply {
            setImageResource(R.drawable.face_smile)
            setColorFilter(cfg.faceColor, PorterDuff.Mode.SRC_IN)
        }
        mini.addView(miniFace, FrameLayout.LayoutParams(dp(56), dp(56)))
        mini.addView(ImageView(this).apply { setImageResource(R.drawable.ball_shade) }, FrameLayout.LayoutParams(dp(56), dp(56)))
        header.addView(mini, LinearLayout.LayoutParams(dp(56), dp(56)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "Крон"
            textSize = 28f
            setTextColor(ink)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        titles.addView(TextView(this).apply {
            text = "Настройки помощника"
            textSize = 14f
            setTextColor(muted)
        })
        header.addView(titles)
        root.addView(header, margins(bottom = 14))

        permStatus = TextView(this).apply {
            textSize = 13f
            setTextColor(ink)
            background = shape(0xFFFFF1BF.toInt(), 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        root.addView(permStatus, margins(bottom = 4))

        // ---------- Помощники для построения ----------
        fun card(title: String): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(Color.WHITE, 18, line)
                setPadding(dp(16), dp(14), dp(16), dp(16))
                elevation = dp(1).toFloat()
            }
            c.addView(TextView(this).apply {
                text = title.uppercase()
                textSize = 12f
                letterSpacing = 0.08f
                setTextColor(muted)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            root.addView(c, margins(top = 12))
            return c
        }

        fun label(parent: LinearLayout, text: String) {
            parent.addView(TextView(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(ink)
            }, margins(top = 12, bottom = 4))
        }

        fun note(parent: LinearLayout, text: String) {
            parent.addView(TextView(this).apply {
                this.text = text
                textSize = 13f
                setTextColor(muted)
            }, margins(top = 6))
        }

        fun field(
            parent: LinearLayout, hint: String, value: String,
            multiline: Boolean = false, secret: Boolean = false
        ): EditText {
            val e = EditText(this).apply {
                this.hint = hint
                setText(value)
                textSize = 15f
                setTextColor(ink)
                setHintTextColor(0xFFB0A998.toInt())
                background = shape(0xFFFAF8F2.toInt(), 12, line)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                inputType = when {
                    secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    else -> InputType.TYPE_CLASS_TEXT
                }
                if (multiline) {
                    minLines = 3
                    gravity = Gravity.TOP
                }
            }
            parent.addView(e, margins(top = 8))
            return e
        }

        fun spinner(parent: LinearLayout, items: List<String>, selected: Int): Spinner {
            val s = Spinner(this)
            s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            s.setSelection(selected.coerceIn(0, items.lastIndex))
            parent.addView(s, margins())
            return s
        }

        fun slider(parent: LinearLayout, label: String, min: Int, max: Int, value: Int, unit: String): () -> Int {
            val tv = TextView(this).apply { textSize = 14f; setTextColor(ink) }
            val sb = SeekBar(this).apply {
                this.max = max - min
                progress = value.coerceIn(min, max) - min
                progressTintList = ColorStateList.valueOf(ink)
                thumbTintList = ColorStateList.valueOf(ink)
            }
            fun refresh() {
                tv.text = "$label: ${sb.progress + min}$unit"
            }
            refresh()
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) = refresh()
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            parent.addView(tv, margins(top = 12))
            parent.addView(sb, margins(top = 2))
            return { sb.progress + min }
        }

        fun checkbox(parent: LinearLayout, text: String, checked: Boolean): CheckBox {
            val c = CheckBox(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(ink)
                isChecked = checked
                buttonTintList = ColorStateList.valueOf(ink)
            }
            parent.addView(c, margins(top = 8))
            return c
        }

        /** kind: 0 = жёлтая главная, 1 = тёмная, 2 = с обводкой */
        fun styledButton(label: String, kind: Int, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            stateListAnimator = null
            setTextColor(if (kind == 1) Color.WHITE else ink)
            background = when (kind) {
                0 -> shape(yellow, 14)
                1 -> shape(ink, 14)
                else -> shape(Color.WHITE, 14, line)
            }
            setOnClickListener { onClick() }
        }

        fun button(parent: LinearLayout, label: String, kind: Int = 2, onClick: () -> Unit) {
            parent.addView(
                styledButton(label, kind, onClick),
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50))
                    .apply { topMargin = dp(8) }
            )
        }

        // ---------- Разделы ----------
        val access = card("Доступ")
        val keyField = field(access, "API-ключ (sk-ant-...)", cfg.apiKey, secret = true)
        note(access, "Ключ хранится только на этом телефоне.")

        val me = card("Крон")
        label(me, "Имя")
        val nameField = field(me, "Имя", cfg.name)
        label(me, "Характер")
        val personaSpinner = spinner(me, Settings.PERSONAS.map { it.first }, cfg.persona)
        val snarkBox = checkbox(me, "Огрызаться, если мне грубят", cfg.snark)
        note(me, "Грубость в ответ на грубость, без мата и оскорблений. Когда вы снова вежливы, Крон тоже.")
        label(me, "Свои инструкции")
        val customField = field(me, "Например: «Зови меня Серик»", cfg.customPrompt, multiline = true)
        label(me, "Длина ответа")
        val lengthSpinner = spinner(me, Settings.LENGTHS.map { it.first }, cfg.length)
        label(me, "Модель Claude")
        val modelSpinner = spinner(me, Settings.MODELS.map { it.first }, cfg.model)

        val ball = card("Шарик")
        var ballColor = cfg.ballColor
        var faceColor = cfg.faceColor
        var syncing = false
        lateinit var hueSeek: SeekBar
        lateinit var valSeek: SeekBar
        val ballDots = mutableListOf<View>()
        val faceDots = mutableListOf<View>()

        fun dotShape(c: Int, selected: Boolean) = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c)
            setStroke(dp(if (selected) 3 else 1), if (selected) ink else line)
        }
        fun repaint() {
            ballDots.forEachIndexed { i, d ->
                val c = Settings.BALL_COLORS[i].second.toInt()
                d.background = dotShape(c, c == ballColor)
            }
            faceDots.forEachIndexed { i, d ->
                val c = Settings.FACE_COLORS[i].second.toInt()
                d.background = dotShape(c, c == faceColor)
            }
            miniBody.setColorFilter(ballColor, PorterDuff.Mode.SRC_IN)
            miniFace.setColorFilter(faceColor, PorterDuff.Mode.SRC_IN)
        }
        fun swatchRow(colors: List<Int>, dots: MutableList<View>, onPick: (Int) -> Unit): LinearLayout {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            colors.forEach { c ->
                val cell = FrameLayout(this)
                val dot = View(this)
                dots.add(dot)
                cell.addView(dot, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
                cell.setOnClickListener { onPick(c) }
                row.addView(cell, LinearLayout.LayoutParams(0, dp(40), 1f))
            }
            return row
        }
        fun colorSeek(max: Int, onChange: () -> Unit): SeekBar = SeekBar(this).apply {
            this.max = max
            progressTintList = ColorStateList.valueOf(ink)
            thumbTintList = ColorStateList.valueOf(ink)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && !syncing) onChange()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        fun syncSeeks() {
            val hsv = FloatArray(3)
            Color.colorToHSV(ballColor, hsv)
            syncing = true
            hueSeek.progress = hsv[0].toInt().coerceIn(0, 360)
            valSeek.progress = (hsv[2] * 100).toInt().coerceIn(40, 100) - 40
            syncing = false
        }

        label(ball, "Цвет шарика")
        ball.addView(swatchRow(Settings.BALL_COLORS.map { it.second.toInt() }, ballDots) { c ->
            ballColor = c
            syncSeeks()
            repaint()
        }, margins(top = 4))
        label(ball, "Свой оттенок")
        hueSeek = colorSeek(360) {
            ballColor = Color.HSVToColor(floatArrayOf(hueSeek.progress.toFloat(), 0.65f, (valSeek.progress + 40) / 100f))
            repaint()
        }
        // полоса оттенков под ползунком
        hueSeek.progressDrawable = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.65f, 1f)) }
        ).apply { cornerRadius = dp(4).toFloat(); setSize(0, dp(8)) }
        hueSeek.progressTintList = null
        ball.addView(hueSeek, margins(top = 2))
        label(ball, "Яркость")
        valSeek = colorSeek(60) {
            ballColor = Color.HSVToColor(floatArrayOf(hueSeek.progress.toFloat(), 0.65f, (valSeek.progress + 40) / 100f))
            repaint()
        }
        ball.addView(valSeek, margins(top = 2))
        syncSeeks()

        label(ball, "Цвет лица")
        ball.addView(swatchRow(Settings.FACE_COLORS.map { it.second.toInt() }, faceDots) { c ->
            faceColor = c
            repaint()
        }, margins(top = 4))
        repaint()

        val getSize = slider(ball, "Размер", 60, 140, cfg.sizeDp, "")
        val getBounce = slider(ball, "Упругость отскока", 20, 80, cfg.bounce, "%")
        label(ball, "Сам прыгает")
        val hopSpinner = spinner(ball, Settings.HOP_LABELS, cfg.hopFreq)

        val screen = card("Экран")
        note(screen, "Крон видит экран только когда показ включён, и только в момент вашего вопроса.")
        label(screen, "Качество снимка")
        val shotSpinner = spinner(screen, Settings.SHOT_QUALITY.map { it.first }, cfg.shotQuality)
        val hideBox = checkbox(screen, "Прятать чат и шарик на снимке", cfg.hideOnShot)
        button(screen, "👁  Включить показ экрана", 2) {
            if (!OverlayService.active) {
                Toast.makeText(this, "Сначала нажмите «Запустить»", Toast.LENGTH_LONG).show()
            } else {
                startActivity(Intent(this, ProjectionActivity::class.java))
            }
        }

        val voice = card("Голос")
        val voiceReplyBox = checkbox(voice, "Озвучивать все ответы", cfg.voiceReply)
        note(voice, "На вопрос, заданный голосом, Крон отвечает вслух всегда.")
        label(voice, "Язык голоса")
        val langs = Settings.allVoiceLangs()
        var voiceTag = cfg.voiceLangTag
        fun langName(tag: String) = langs.firstOrNull { it.second == tag }?.first ?: tag
        val langBtn = styledButton(langName(voiceTag), 2) {}
        langBtn.setOnClickListener {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(8), dp(16), 0)
            }
            val search = EditText(this).apply {
                hint = "Поиск языка"
                setSingleLine()
            }
            val list = ListView(this)
            var shown = langs
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown.map { it.first }.toMutableList())
            list.adapter = adapter
            box.addView(search)
            box.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(360)))
            val dlg = AlertDialog.Builder(this)
                .setTitle("Язык голоса")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .create()
            search.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val q = e?.toString()?.trim().orEmpty()
                    shown = langs.filter { it.first.contains(q, true) || it.second.contains(q, true) }
                    adapter.clear()
                    adapter.addAll(shown.map { it.first })
                    adapter.notifyDataSetChanged()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            list.setOnItemClickListener { _, _, pos, _ ->
                voiceTag = shown[pos].second
                langBtn.text = shown[pos].first
                dlg.dismiss()
            }
            dlg.show()
        }
        voice.addView(langBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)))
        note(voice, "Доступны все языки, которые знает телефон. Распознавание и озвучка работают для тех, что поддерживает Google. Недостающие голоса скачайте в настройках телефона («Синтез речи»).")

        // ---------- Управление ----------
        val ctl = card("Управление")
        button(ctl, "Сохранить настройки", 0) {
            cfg.apiKey = keyField.text.toString().trim()
            cfg.name = nameField.text.toString().trim()
            cfg.persona = personaSpinner.selectedItemPosition
            cfg.snark = snarkBox.isChecked
            cfg.customPrompt = customField.text.toString()
            cfg.length = lengthSpinner.selectedItemPosition
            cfg.model = modelSpinner.selectedItemPosition
            cfg.sizeDp = getSize()
            cfg.bounce = getBounce()
            cfg.hopFreq = hopSpinner.selectedItemPosition
            cfg.ballColor = ballColor
            cfg.faceColor = faceColor
            cfg.shotQuality = shotSpinner.selectedItemPosition
            cfg.hideOnShot = hideBox.isChecked
            cfg.voiceReply = voiceReplyBox.isChecked
            cfg.voiceLangTag = voiceTag

            val service = Intent(this, OverlayService::class.java)
            if (OverlayService.active) {
                // помощник уже на экране: перезапускаем, чтобы настройки применились
                stopService(service)
                startForegroundService(service)
            }
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }

        val runRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        runRow.addView(
            styledButton("▶  Запустить", 1) {
                if (!AndroidSettings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Сначала дайте разрешение «поверх других окон»", Toast.LENGTH_LONG).show()
                } else {
                    if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    }
                    startForegroundService(Intent(this, OverlayService::class.java))
                    permStatus.postDelayed({ refreshStatus() }, 600)
                }
            },
            LinearLayout.LayoutParams(0, dp(50), 1f)
        )
        runRow.addView(
            styledButton("■  Остановить", 2) {
                stopService(Intent(this, OverlayService::class.java))
                permStatus.postDelayed({ refreshStatus() }, 600)
            },
            LinearLayout.LayoutParams(0, dp(50), 1f).apply { leftMargin = dp(8) }
        )
        ctl.addView(runRow, margins(top = 8))

        label(ctl, "Разрешения")
        button(ctl, "Разрешить поверх других окон", 2) {
            startActivity(
                Intent(
                    AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        button(ctl, "Разрешить микрофон", 2) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Микрофон уже разрешён", Toast.LENGTH_SHORT).show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        val overlay = AndroidSettings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        fun mark(ok: Boolean) = if (ok) "✓" else "✗"
        permStatus.text = "Поверх окон ${mark(overlay)}   ·   Микрофон ${mark(mic)}   ·   " +
            if (OverlayService.active) "Крон на экране" else "Крон остановлен"
    }
}
